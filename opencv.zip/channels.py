import numpy as np
import argparse
import imutils
import cv2

#fetching the arguments and saving the dictionary
ap=argparse.ArgumentParser()
ap.add_argument("-i", "--image", required=True, help="Enter path to the image")
args=vars(ap.parse_args())

#loading and converting image into numpy array
#printing teh corresponding text
image=cv2.imread(args["image"])
cv2.imshow("original image", image)
cv2.waitKey(5000)

#split the image based on channels
(B,G,R)=cv2.split(image)

cv2.imshow("Red",R)
cv2.imshow("Green", G)
cv2.imshow("Blue", B)
cv2.waitKey(15000)

#alternate method
zeros=np.zeros(image.shape[:2], dtype="uint8")
cv2.imshow("Red", cv2.merge([zeros, zeros, R]))
cv2.imshow("Green", cv2.merge([zeros, G, zeros]))
cv2.imshow("Blue", cv2.merge([B, zeros, zeros]))
cv2.waitKey(15000)

#merge back the channels
merged=cv2.merge([B, G, R])
cv2.imshow("Merged", merged)
cv2.waitKey(10000)