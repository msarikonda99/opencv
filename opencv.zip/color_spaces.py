import numpy as np
import argparse
import imutils
import cv2

#fetching the arguments and saving the dictionary
ap=argparse.ArgumentParser()
ap.add_argument("-i", "--image", required=True, help="Enter path to the image")
args=vars(ap.parse_args())

#loading and converting image into numpy array
#printing teh corresponding text
image=cv2.imread(args["image"])
cv2.imshow("BGR Color Space", image)
cv2.waitKey(5000)

#BGR to GREY
gray=cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
cv2.imshow("GRAY", gray)
cv2.waitKey(5000)

#BGR to HSV
hsv=cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
cv2.imshow("HSV", hsv)
cv2.waitKey(5000)

#BGR to LAB
lab=cv2.cvtColor(image, cv2.COLOR_BGR2LAB)
cv2.imshow("LAB", lab)
cv2.waitKey(5000)