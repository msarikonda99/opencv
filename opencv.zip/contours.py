import numpy as np
import argparse
import cv2
import imutils

#fetching the arguments and saving the dictionary
ap=argparse.ArgumentParser()
ap.add_argument("-i", "--image", required=True, help="Enter path to the image")
args=vars(ap.parse_args())

#loading and converting image into numpy array
#printing teh corresponding text
image=cv2.imread(args["image"])

#convert image to gray scale
gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

#implement gaussian blur
blurred = cv2.GaussianBlur(image, (16,16), 0)
cv2.imshow("Gaussian Blur", blurred)

canny=cv2.Canny(blurred, 30, 150)
cv2.imshow("Canny detected", canny)

#finding the contours , counting and marking them
(cnts, _) = cv2.findContours(canny.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
print("The number of coins in the image is : {}". format(len(cnts)))

#create a copy of the image
coins= image.copy()

#drwa the contours in the actual image copy
cv2.drawContours(coins, cnts, -1, (0,255,0), 2)
cv2.imshow("Contours", coins)

cv2.waitKey(12000)