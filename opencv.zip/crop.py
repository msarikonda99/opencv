import argparse
import imutils
import cv2

#fetching the arguments and saving the dictionary
ap=argparse.ArgumentParser()
ap.add_argument("-i", "--image", required=True, help="Enter path to the image")
args=vars(ap.parse_args())

#loading and converting image into numpy array
#printing teh corresponding text
image=cv2.imread(args["image"])
cv2.imshow("original image", image)
cv2.waitKey(5000)

#crop the image
#start y 15: end y 222, start x 150: end x 200
cropped=image[15:222,150:400]
cv2.imshow("Cropped", cropped)
cv2.waitKey(5000)