from tkinter import *
from matplotlib import pyplot as plt
import numpy as np
import argparse
import imutils
import cv2

#fetching the arguments and saving the dictionary
ap=argparse.ArgumentParser()
ap.add_argument("-i", "--image", required=True, help="Enter path to the image")
args=vars(ap.parse_args())

#loading and converting image into numpy array
#printing teh corresponding text
image=cv2.imread(args["image"])

#BGR to GREY
gray=cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
cv2.imshow("GRAY", gray)

#create the histogram
hist=cv2.calcHist([gray], [0], None, [256], [0,256])

#plot the graph
plt.figure()
plt.title("Grayscale Histogram")
plt.xlabel("bins")
plt.ylabel("No. of pixels")
plt.plot(hist)
plt.xlim([0,256])
plt.show()

cv2.waitKey(1000)
