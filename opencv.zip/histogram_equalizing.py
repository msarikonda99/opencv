import numpy as np
import argparse
import cv2

#fetching the arguments and saving the dictionary
ap=argparse.ArgumentParser()
ap.add_argument("-i", "--image", required=True, help="Enter path to the image")
args=vars(ap.parse_args())

#loading and converting image into numpy array
#printing teh corresponding text
image=cv2.imread(args["image"])

#BGR to GREY
gray=cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
cv2.imshow("GRAY", gray)
cv2.waitKey(10000)

eq=cv2.equalizeHist(gray)
cv2.imshow("No,al and Equalized",np.hstack([gray, eq]))
cv2.waitKey(10000)