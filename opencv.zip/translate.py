import argparse
import imutils
import cv2

#fetching the arguments and saving the dictionary
ap=argparse.ArgumentParser()
ap.add_argument("-i", "--image", required=True, help="Enter path to the image")
args=vars(ap.parse_args())

#loading and converting image into numpy array
#printing teh corresponding text
image=cv2.imread(args["image"])

#shifting the image down
shifted=imutils.translate(image, 0, 100)
cv2.imshow("shifted down image", shifted)
cv2.waitKey(10000)

#shifting the image up
shifted=imutils.translate(image, 0, -100)
cv2.imshow("shifted up image", shifted)
cv2.waitKey(10000)

#shifting the image left
shifted=imutils.translate(image, -100, 0)
cv2.imshow("shifted left image", shifted)
cv2.waitKey(10000)


#shifting the image right
shifted=imutils.translate(image, 100, 0)
cv2.imshow("shifted right image", shifted)
cv2.waitKey(10000)

#shifting the image right and down
shifted=imutils.translate(image, 100, 50)
cv2.imshow("shifted right image", shifted)
cv2.waitKey(10000)